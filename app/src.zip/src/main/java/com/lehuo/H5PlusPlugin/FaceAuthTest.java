package com.lehuo.H5PlusPlugin;

public class FaceAuthTest {
    private String udauthKey = "94f8121a-6776-427c-9e53-5e4513a1b757";
    private String udNotifyURL= "http://www.baidu.com";

    public void test_faceauth(String memid) throws java.io.IOException {
//        Context ctx = cordova.getActivity();
//        final MainActivity act = (MainActivity) ctx;
//        System.out.println("getRealnameAuth");
//        act.appcreate = true;
//        act.outin = true;
//        String id = memid+"U"+new Date().getTime();
//        AuthBuilder mAuthBuilder = new AuthBuilder(id, udauthKey, udNotifyURL, new OnResultListener() {
//            @Override
//            public void onResult(String s) {
//                callbackContext.success(s);
//            }
//        });
//        mAuthBuilder.faceAuth(act);
//        System.out.println("getRealnameAuth");
//        AuthBuilder mAuthBuilder = new AuthBuilder(id, udauthKey, udNotifyURL, new OnResultListener() {
//            public void onResult(String s, JSONObject object) {
//                tv_result.setText("result:" + s);
//                /* 获取bitmap */
//                Bitmap bitmap = (Bitmap) object.opt("sdk_xxxxxxxxxxxx");
//                /* setImageBitmap调用时，需要对bitmap对象做压缩处理，否则可能会出现bitmap过大被系统自动回收 */
//            }
//        });
//        mAuthBuilder.faceAuth(Context context);
    }
}